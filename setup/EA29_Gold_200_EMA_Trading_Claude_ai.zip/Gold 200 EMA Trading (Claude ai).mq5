//+------------------------------------------------------------------+
//|                                            EMA200_Strategy_EA.mq5 |
//|                                    EMA 200 Trend Following Strategy |
//|                                              For XAU/USD H1 Chart |
//+------------------------------------------------------------------+
#property copyright "EMA 200 Trend Strategy"
#property link      ""
#property version   "1.00"
#property description "Simple EMA 200 trend following strategy with optional RSI filter"

#include <Trade\Trade.mqh>

//--- Input Parameters
input group "=== Indicator Settings ==="
input int      EMA_Period = 200;                    // EMA Period
input bool     UseRSIFilter = true;                 // Use RSI Filter
input int      RSI_Period = 14;                     // RSI Period
input double   RSI_Level = 50.0;                    // RSI Level (for trend confirmation)

input group "=== Entry Settings ==="
input double   PullbackDistance = 100;              // Pullback Distance from EMA (points)
input bool     RequireEngulfing = false;            // Require Engulfing Candle Pattern

input group "=== Money Management ==="
input double   LotSize = 0.01;                      // Fixed Lot Size
input double   RiskPerTrade = 1.0;                  // Risk Per Trade (%)
input bool     UseFixedLot = true;                  // Use Fixed Lot Size (false = use risk%)

input group "=== Stop Loss & Take Profit ==="
input int      SL_Points = 500;                     // Stop Loss (points)
input int      TP_Points = 1000;                    // Take Profit (points)
input bool     UseDynamicSLTP = true;              // Use ATR-based SL/TP
input int      ATR_Period = 14;                     // ATR Period
input double   ATR_SL_Multiplier = 2.0;             // ATR Multiplier for SL
input double   ATR_TP_Multiplier = 4.0;             // ATR Multiplier for TP

input group "=== Trade Management ==="
input bool     UseTrailingStop = false;              // Use Trailing Stop
input int      TrailingStop_Points = 500;           // Trailing Stop Distance (points)
input int      TrailingStep_Points = 100;           // Trailing Step (points)
input bool     MoveToBreakEven = false;              // Move to Break Even
input int      BreakEven_Points = 500;              // Break Even Trigger (points)
input int      BreakEven_Profit = 50;               // Break Even Profit Lock (points)

input group "=== Risk Management ==="
input int      MaxOpenTrades = 1;                   // Max Open Trades
input bool     CloseOnTrendChange = true;           // Close on Trend Change
input bool     TradeOnlyActiveSessions = false;     // Trade Only During Active Sessions

input group "=== Expert Advisor Settings ==="
input int      MagicNumber = 123456;                // Magic Number
input string   TradeComment = "EMA200_Strategy";    // Trade Comment

//--- Global Variables
CTrade trade;
int emaHandle;
int rsiHandle;
int atrHandle;
double emaBuffer[];
double rsiBuffer[];
double atrBuffer[];
datetime lastBarTime = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   //--- Set trade parameters
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(50);
   trade.SetTypeFilling(ORDER_FILLING_IOC);
   
   //--- Create EMA indicator
   emaHandle = iMA(_Symbol, PERIOD_H1, EMA_Period, 0, MODE_EMA, PRICE_CLOSE);
   if(emaHandle == INVALID_HANDLE)
   {
      Print("Error creating EMA indicator");
      return(INIT_FAILED);
   }
   
   //--- Create RSI indicator if enabled
   if(UseRSIFilter)
   {
      rsiHandle = iRSI(_Symbol, PERIOD_H1, RSI_Period, PRICE_CLOSE);
      if(rsiHandle == INVALID_HANDLE)
      {
         Print("Error creating RSI indicator");
         return(INIT_FAILED);
      }
   }
   
   //--- Create ATR indicator if dynamic SL/TP enabled
   if(UseDynamicSLTP)
   {
      atrHandle = iATR(_Symbol, PERIOD_H1, ATR_Period);
      if(atrHandle == INVALID_HANDLE)
      {
         Print("Error creating ATR indicator");
         return(INIT_FAILED);
      }
   }
   
   //--- Set array as series
   ArraySetAsSeries(emaBuffer, true);
   ArraySetAsSeries(rsiBuffer, true);
   ArraySetAsSeries(atrBuffer, true);
   
   Print("EMA 200 Strategy EA initialized successfully");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   //--- Release indicator handles
   if(emaHandle != INVALID_HANDLE) IndicatorRelease(emaHandle);
   if(rsiHandle != INVALID_HANDLE) IndicatorRelease(rsiHandle);
   if(atrHandle != INVALID_HANDLE) IndicatorRelease(atrHandle);
   
   Print("EMA 200 Strategy EA deinitialized");
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
//Show Equity and Balance
Comment ( StringFormat ( "Equity is %.2f and Balance is %.2f", AccountInfoDouble (ACCOUNT_EQUITY), AccountInfoDouble(ACCOUNT_BALANCE)));

   //--- Check for new bar
   datetime currentBarTime = iTime(_Symbol, PERIOD_H1, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;
   
   //--- Check trading session
   if(TradeOnlyActiveSessions && !IsActiveTradingSession()) return;
   
   //--- Update indicator buffers
   if(!UpdateIndicators()) return;
   
   //--- Manage existing positions
   ManagePositions();
   
   //--- Check for new trade signals
   if(CountOpenPositions() >= MaxOpenTrades) return;
   
   //--- Check for buy signal
   if(CheckBuySignal())
   {
      OpenBuyTrade();
   }
   //--- Check for sell signal
   else if(CheckSellSignal())
   {
      OpenSellTrade();
   }
}

//+------------------------------------------------------------------+
//| Update indicator buffers                                         |
//+------------------------------------------------------------------+
bool UpdateIndicators()
{
   //--- Copy EMA values
   if(CopyBuffer(emaHandle, 0, 0, 3, emaBuffer) <= 0)
   {
      Print("Error copying EMA buffer");
      return false;
   }
   
   //--- Copy RSI values if enabled
   if(UseRSIFilter)
   {
      if(CopyBuffer(rsiHandle, 0, 0, 3, rsiBuffer) <= 0)
      {
         Print("Error copying RSI buffer");
         return false;
      }
   }
   
   //--- Copy ATR values if dynamic SL/TP enabled
   if(UseDynamicSLTP)
   {
      if(CopyBuffer(atrHandle, 0, 0, 3, atrBuffer) <= 0)
      {
         Print("Error copying ATR buffer");
         return false;
      }
   }
   
   return true;
}

//+------------------------------------------------------------------+
//| Check for buy signal                                             |
//+------------------------------------------------------------------+
bool CheckBuySignal()
{
   double close1 = iClose(_Symbol, PERIOD_H1, 1);
   double close2 = iClose(_Symbol, PERIOD_H1, 2);
   double high1 = iHigh(_Symbol, PERIOD_H1, 1);
   double high2 = iHigh(_Symbol, PERIOD_H1, 2);
   double low1 = iLow(_Symbol, PERIOD_H1, 1);
   double low2 = iLow(_Symbol, PERIOD_H1, 2);
   double open1 = iOpen(_Symbol, PERIOD_H1, 1);
   double open2 = iOpen(_Symbol, PERIOD_H1, 2);
   
   //--- Trend Filter: Price must be above EMA 200
   if(close1 <= emaBuffer[1]) return false;
   
   //--- Pullback condition: Previous candle was near EMA
   double distanceFromEMA = MathAbs(close2 - emaBuffer[2]);
   double pullbackThreshold = PullbackDistance * _Point;
   
   //--- Reversal confirmation: Bullish candle closes above previous high
   bool bullishReversal = close1 > high2;
   
   //--- Optional: Check for bullish engulfing pattern
   if(RequireEngulfing)
   {
      bool isEngulfing = (close1 > open1 && close2 < open2 && 
                          open1 <= close2 && close1 >= open2);
      if(!isEngulfing) return false;
   }
   
   //--- RSI Filter (optional)
   if(UseRSIFilter)
   {
      if(rsiBuffer[1] <= RSI_Level) return false;
   }
   
   //--- All conditions met
   return (distanceFromEMA <= pullbackThreshold || close2 < emaBuffer[2]) && bullishReversal;
}

//+------------------------------------------------------------------+
//| Check for sell signal                                            |
//+------------------------------------------------------------------+
bool CheckSellSignal()
{
   double close1 = iClose(_Symbol, PERIOD_H1, 1);
   double close2 = iClose(_Symbol, PERIOD_H1, 2);
   double low1 = iLow(_Symbol, PERIOD_H1, 1);
   double low2 = iLow(_Symbol, PERIOD_H1, 2);
   double high1 = iHigh(_Symbol, PERIOD_H1, 1);
   double high2 = iHigh(_Symbol, PERIOD_H1, 2);
   double open1 = iOpen(_Symbol, PERIOD_H1, 1);
   double open2 = iOpen(_Symbol, PERIOD_H1, 2);
   
   //--- Trend Filter: Price must be below EMA 200
   if(close1 >= emaBuffer[1]) return false;
   
   //--- Pullback condition: Previous candle was near EMA
   double distanceFromEMA = MathAbs(close2 - emaBuffer[2]);
   double pullbackThreshold = PullbackDistance * _Point;
   
   //--- Reversal confirmation: Bearish candle closes below previous low
   bool bearishReversal = close1 < low2;
   
   //--- Optional: Check for bearish engulfing pattern
   if(RequireEngulfing)
   {
      bool isEngulfing = (close1 < open1 && close2 > open2 && 
                          open1 >= close2 && close1 <= open2);
      if(!isEngulfing) return false;
   }
   
   //--- RSI Filter (optional)
   if(UseRSIFilter)
   {
      if(rsiBuffer[1] >= RSI_Level) return false;
   }
   
   //--- All conditions met
   return (distanceFromEMA <= pullbackThreshold || close2 > emaBuffer[2]) && bearishReversal;
}

//+------------------------------------------------------------------+
//| Open buy trade                                                   |
//+------------------------------------------------------------------+
void OpenBuyTrade()
{
   double price = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double sl, tp;
   
   //--- Calculate SL and TP
   CalculateSLTP(ORDER_TYPE_BUY, price, sl, tp);
   
   //--- Calculate lot size
   double lots = CalculateLotSize(sl, price);
   
   //--- Normalize values
   price = NormalizeDouble(price, _Digits);
   sl = NormalizeDouble(sl, _Digits);
   tp = NormalizeDouble(tp, _Digits);
   
   //--- Open trade
   if(trade.Buy(lots, _Symbol, price, sl, tp, TradeComment))
   {
      Print("Buy order opened: Price=", price, " SL=", sl, " TP=", tp, " Lots=", lots);
   }
   else
   {
      Print("Error opening buy order: ", GetLastError());
   }
}

//+------------------------------------------------------------------+
//| Open sell trade                                                  |
//+------------------------------------------------------------------+
void OpenSellTrade()
{
   double price = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double sl, tp;
   
   //--- Calculate SL and TP
   CalculateSLTP(ORDER_TYPE_SELL, price, sl, tp);
   
   //--- Calculate lot size
   double lots = CalculateLotSize(sl, price);
   
   //--- Normalize values
   price = NormalizeDouble(price, _Digits);
   sl = NormalizeDouble(sl, _Digits);
   tp = NormalizeDouble(tp, _Digits);
   
   //--- Open trade
   if(trade.Sell(lots, _Symbol, price, sl, tp, TradeComment))
   {
      Print("Sell order opened: Price=", price, " SL=", sl, " TP=", tp, " Lots=", lots);
   }
   else
   {
      Print("Error opening sell order: ", GetLastError());
   }
}

//+------------------------------------------------------------------+
//| Calculate Stop Loss and Take Profit                             |
//+------------------------------------------------------------------+
void CalculateSLTP(ENUM_ORDER_TYPE orderType, double entryPrice, double &sl, double &tp)
{
   double slDistance, tpDistance;
   
   if(UseDynamicSLTP)
   {
      //--- Use ATR-based SL/TP
      double atr = atrBuffer[1];
      slDistance = atr * ATR_SL_Multiplier;
      tpDistance = atr * ATR_TP_Multiplier;
   }
   else
   {
      //--- Use fixed SL/TP
      slDistance = SL_Points * _Point;
      tpDistance = TP_Points * _Point;
   }
   
   if(orderType == ORDER_TYPE_BUY)
   {
      sl = entryPrice - slDistance;
      tp = entryPrice + tpDistance;
   }
   else // SELL
   {
      sl = entryPrice + slDistance;
      tp = entryPrice - tpDistance;
   }
}

//+------------------------------------------------------------------+
//| Calculate lot size based on risk                                |
//+------------------------------------------------------------------+
double CalculateLotSize(double sl, double entryPrice)
{
   if(UseFixedLot) return LotSize;
   
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskAmount = balance * RiskPerTrade / 100.0;
   double slDistance = MathAbs(entryPrice - sl);
   
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   
   double lots = riskAmount / (slDistance / tickSize * tickValue);
   
   //--- Normalize lot size
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   
   lots = MathFloor(lots / lotStep) * lotStep;
   lots = MathMax(minLot, MathMin(maxLot, lots));
   
   return lots;
}

//+------------------------------------------------------------------+
//| Manage existing positions                                        |
//+------------------------------------------------------------------+
void ManagePositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket <= 0) continue;
      
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      
      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double posOpenPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double posSL = PositionGetDouble(POSITION_SL);
      double posTP = PositionGetDouble(POSITION_TP);
      
      //--- Close on trend change
      if(CloseOnTrendChange)
      {
         double currentClose = iClose(_Symbol, PERIOD_H1, 0);
         if(posType == POSITION_TYPE_BUY && currentClose < emaBuffer[0])
         {
            trade.PositionClose(ticket);
            Print("Buy position closed due to trend change");
            continue;
         }
         if(posType == POSITION_TYPE_SELL && currentClose > emaBuffer[0])
         {
            trade.PositionClose(ticket);
            Print("Sell position closed due to trend change");
            continue;
         }
      }
      
      //--- Trailing Stop
      if(UseTrailingStop)
      {
         ApplyTrailingStop(ticket, posType, posOpenPrice, posSL);
      }
      
      //--- Move to Break Even
      if(MoveToBreakEven)
      {
         ApplyBreakEven(ticket, posType, posOpenPrice, posSL);
      }
   }
}

//+------------------------------------------------------------------+
//| Apply trailing stop                                             |
//+------------------------------------------------------------------+
void ApplyTrailingStop(ulong ticket, ENUM_POSITION_TYPE posType, double openPrice, double currentSL)
{
   double currentPrice = (posType == POSITION_TYPE_BUY) ? 
                         SymbolInfoDouble(_Symbol, SYMBOL_BID) : 
                         SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   
   double trailDistance = TrailingStop_Points * _Point;
   double trailStep = TrailingStep_Points * _Point;
   
   if(posType == POSITION_TYPE_BUY)
   {
      double newSL = currentPrice - trailDistance;
      if(newSL > currentSL + trailStep && newSL > openPrice)
      {
         newSL = NormalizeDouble(newSL, _Digits);
         trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
         Print("Trailing stop applied for buy position: New SL=", newSL);
      }
   }
   else // SELL
   {
      double newSL = currentPrice + trailDistance;
      if((currentSL == 0 || newSL < currentSL - trailStep) && newSL < openPrice)
      {
         newSL = NormalizeDouble(newSL, _Digits);
         trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
         Print("Trailing stop applied for sell position: New SL=", newSL);
      }
   }
}

//+------------------------------------------------------------------+
//| Apply break even                                                |
//+------------------------------------------------------------------+
void ApplyBreakEven(ulong ticket, ENUM_POSITION_TYPE posType, double openPrice, double currentSL)
{
   double currentPrice = (posType == POSITION_TYPE_BUY) ? 
                         SymbolInfoDouble(_Symbol, SYMBOL_BID) : 
                         SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   
   double beTrigger = BreakEven_Points * _Point;
   double beProfit = BreakEven_Profit * _Point;
   
   if(posType == POSITION_TYPE_BUY)
   {
      if(currentPrice >= openPrice + beTrigger && currentSL < openPrice)
      {
         double newSL = NormalizeDouble(openPrice + beProfit, _Digits);
         trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
         Print("Break even applied for buy position: New SL=", newSL);
      }
   }
   else // SELL
   {
      if(currentPrice <= openPrice - beTrigger && (currentSL == 0 || currentSL > openPrice))
      {
         double newSL = NormalizeDouble(openPrice - beProfit, _Digits);
         trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
         Print("Break even applied for sell position: New SL=", newSL);
      }
   }
}

//+------------------------------------------------------------------+
//| Count open positions                                            |
//+------------------------------------------------------------------+
int CountOpenPositions()
{
   int count = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket <= 0) continue;
      
      if(PositionGetString(POSITION_SYMBOL) == _Symbol && 
         PositionGetInteger(POSITION_MAGIC) == MagicNumber)
      {
         count++;
      }
   }
   return count;
}

//+------------------------------------------------------------------+
//| Check if current time is in active trading session              |
//+------------------------------------------------------------------+
bool IsActiveTradingSession()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   
   //--- London and New York sessions (02:00 - 20:00 GMT)
   if(dt.hour >= 2 && dt.hour < 20) return true;
   
   return false;
}

//+------------------------------------------------------------------+