//+------------------------------------------------------------------+
//| Price Action BOS Retest Rejection EA                             |
//| Strategy: XAUUSD H1 Price Action Swing Trading                  |
//| Designed to work on any symbol/timeframe, with H1 default       |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "BOS -> Retest -> Rejection price-action EA"
#property description "Based on the supplied Price Action Swing Trading Strategy."

#include <Trade/Trade.mqh>

CTrade trade;

//--- Trading
input group "Trading"
input ulong            InpMagicNumber          = 26081701;
input double           InpRiskPercent          = 1.0;      // Risk per trade (%)
input double           InpFixedLot             = 0.0;      // 0 = calculate lot from risk %
input ENUM_TIMEFRAMES  InpSignalTimeframe      = PERIOD_H1;
input bool             InpAllowBuy             = true;
input bool             InpAllowSell            = true;
input int              InpMaxSpreadPoints      = 0;        // 0 = disabled
input int              InpDeviationPoints      = 30;

//--- Market structure
input group "Market Structure"
input int              InpSwingStrength        = 3;        // Pivot bars left/right
input int              InpMinSwingDistancePts  = 0;        // 0 = disabled
input int              InpMaxBarsAfterBOS      = 30;       // Setup expiry
input ENUM_TIMEFRAMES  InpHTF1                  = PERIOD_H4;
input ENUM_TIMEFRAMES  InpHTF2                  = PERIOD_D1;
input int              InpHTFSwingStrength      = 3;

//--- Retest
input group "Retest"
input double           InpRetestToleranceATR   = 0.25;     // Level tolerance in ATR
input int              InpMinRetestBars        = 1;
input int              InpMaxRetestBars        = 12;

//--- Rejection confirmation
input group "Rejection Confirmation"
input bool             InpUsePinBar             = true;
input bool             InpUseEngulfing          = true;
input bool             InpUseStrongRejection    = true;
input bool             InpUseMarubozu           = true;
input double           InpPinWickBodyRatio      = 2.0;
input double           InpStrongWickRatio       = 1.5;
input double           InpMarubozuWickRatio     = 0.15;
input double           InpMaxCandleATR          = 2.5;      // Reject oversized candle; 0=disabled

//--- Stop / target
input group "Stop Loss & Take Profit"
input int              InpATRPeriod             = 14;
input double           InpSLBufferATR            = 0.20;
input double           InpRiskReward             = 2.0;
input double           InpMaxSLDistanceATR      = 4.0;      // 0=disabled

//--- State
enum SetupDirection
{
   SETUP_NONE = 0,
   SETUP_BUY  = 1,
   SETUP_SELL = -1
};

struct SetupState
{
   SetupDirection direction;
   double         level;
   datetime       bosTime;
   int            bosShift;
   bool           retested;
   bool           traded;
};

SetupState g_setup;
int        g_atrHandle = INVALID_HANDLE;
datetime   g_lastBarTime = 0;

//+------------------------------------------------------------------+
//| Utility                                                          |
//+------------------------------------------------------------------+
void ResetSetup()
{
   g_setup.direction = SETUP_NONE;
   g_setup.level     = 0.0;
   g_setup.bosTime   = 0;
   g_setup.bosShift  = -1;
   g_setup.retested  = false;
   g_setup.traded    = false;
}

bool IsNewBar()
{
   datetime t = iTime(_Symbol, InpSignalTimeframe, 0);
   if(t == 0)
      return false;

   if(t != g_lastBarTime)
   {
      g_lastBarTime = t;
      return true;
   }
   return false;
}

double GetATR(const int shift)
{
   if(g_atrHandle == INVALID_HANDLE)
      return 0.0;

   double buffer[];
   ArraySetAsSeries(buffer, true);

   if(CopyBuffer(g_atrHandle, 0, shift, 1, buffer) != 1)
      return 0.0;

   return buffer[0];
}

bool GetRates(MqlRates &rates[], const int count)
{
   ArraySetAsSeries(rates, true);
   int copied = CopyRates(_Symbol, InpSignalTimeframe, 0, count, rates);
   return (copied == count);
}

bool IsPivotHigh(const MqlRates &r[], const int shift, const int strength)
{
   double h = r[shift].high;

   for(int k=1; k<=strength; k++)
   {
      if(h <= r[shift-k].high || h <= r[shift+k].high)
         return false;
   }
   return true;
}

bool IsPivotLow(const MqlRates &r[], const int shift, const int strength)
{
   double l = r[shift].low;

   for(int k=1; k<=strength; k++)
   {
      if(l >= r[shift-k].low || l >= r[shift+k].low)
         return false;
   }
   return true;
}

bool FindRecentPivots(const ENUM_TIMEFRAMES tf,
                      const int strength,
                      double &lastHigh, double &prevHigh,
                      double &lastLow,  double &prevLow)
{
   int bars = Bars(_Symbol, tf);
   int required = MathMax(100, strength * 4 + 30);
   if(bars < required)
      return false;

   MqlRates r[];
   ArraySetAsSeries(r, true);

   int copyCount = MathMin(bars, 300);
   if(CopyRates(_Symbol, tf, 0, copyCount, r) < required)
      return false;

   lastHigh = prevHigh = 0.0;
   lastLow  = prevLow  = 0.0;

   // Start far enough back so shift+strength is valid.
   for(int i=strength+1; i<copyCount-strength; i++)
   {
      if(lastHigh == 0.0 && IsPivotHigh(r, i, strength))
         lastHigh = r[i].high;
      else if(lastHigh != 0.0 && prevHigh == 0.0 && IsPivotHigh(r, i, strength))
         prevHigh = r[i].high;

      if(lastLow == 0.0 && IsPivotLow(r, i, strength))
         lastLow = r[i].low;
      else if(lastLow != 0.0 && prevLow == 0.0 && IsPivotLow(r, i, strength))
         prevLow = r[i].low;

      if(prevHigh != 0.0 && prevLow != 0.0)
         break;
   }

   return (lastHigh > 0.0 && prevHigh > 0.0 && lastLow > 0.0 && prevLow > 0.0);
}

bool IsHTFBullish()
{
   double h1,h2,l1,l2;
   if(!FindRecentPivots(InpHTF1, InpHTFSwingStrength, h1,h2,l1,l2))
      return false;

   bool h4Bull = (h1 > h2 && l1 > l2);

   // Daily context is a preference/context filter. If unavailable, H4 is used.
   double dH1,dH2,dL1,dL2;
   if(!FindRecentPivots(InpHTF2, InpHTFSwingStrength, dH1,dH2,dL1,dL2))
      return h4Bull;

   bool dailyBull = (dH1 > dH2 && dL1 > dL2);
   return (h4Bull && dailyBull);
}

bool IsHTFBearish()
{
   double h1,h2,l1,l2;
   if(!FindRecentPivots(InpHTF1, InpHTFSwingStrength, h1,h2,l1,l2))
      return false;

   bool h4Bear = (h1 < h2 && l1 < l2);

   double dH1,dH2,dL1,dL2;
   if(!FindRecentPivots(InpHTF2, InpHTFSwingStrength, dH1,dH2,dL1,dL2))
      return h4Bear;

   bool dailyBear = (dH1 < dH2 && dL1 < dL2);
   return (h4Bear && dailyBear);
}

bool H1BullishStructure()
{
   double h1,h2,l1,l2;
   if(!FindRecentPivots(InpSignalTimeframe, InpSwingStrength, h1,h2,l1,l2))
      return false;
   return (h1 > h2 && l1 > l2);
}

bool H1BearishStructure()
{
   double h1,h2,l1,l2;
   if(!FindRecentPivots(InpSignalTimeframe, InpSwingStrength, h1,h2,l1,l2))
      return false;
   return (h1 < h2 && l1 < l2);
}

bool GetMostRecentSwingHigh(double &level, int &shift)
{
   MqlRates r[];
   if(!GetRates(r, 300))
      return false;

   for(int i=InpSwingStrength+1; i<295-InpSwingStrength; i++)
   {
      if(IsPivotHigh(r, i, InpSwingStrength))
      {
         level = r[i].high;
         shift = i;
         return true;
      }
   }
   return false;
}

bool GetMostRecentSwingLow(double &level, int &shift)
{
   MqlRates r[];
   if(!GetRates(r, 300))
      return false;

   for(int i=InpSwingStrength+1; i<295-InpSwingStrength; i++)
   {
      if(IsPivotLow(r, i, InpSwingStrength))
      {
         level = r[i].low;
         shift = i;
         return true;
      }
   }
   return false;
}

bool HasOpenPosition()
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;

      if(PositionGetString(POSITION_SYMBOL) == _Symbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC) == InpMagicNumber)
         return true;
   }
   return false;
}

bool SpreadOK()
{
   if(InpMaxSpreadPoints <= 0)
      return true;

   long spread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);
   return (spread <= InpMaxSpreadPoints);
}

double NormalizeVolume(double volume)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double stepLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(stepLot <= 0.0)
      return 0.0;

   volume = MathMax(minLot, MathMin(maxLot, volume));
   volume = MathFloor(volume / stepLot) * stepLot;

   int digits = 0;
   double s = stepLot;
   while(s < 1.0 && digits < 8)
   {
      s *= 10.0;
      digits++;
   }
   return NormalizeDouble(volume, digits);
}

double CalculateRiskLot(const ENUM_ORDER_TYPE type,
                        const double entry,
                        const double stop)
{
   if(InpFixedLot > 0.0)
      return NormalizeVolume(InpFixedLot);

   if(InpRiskPercent <= 0.0)
      return 0.0;

   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskMoney = equity * InpRiskPercent / 100.0;
   if(riskMoney <= 0.0)
      return 0.0;

   double profitOneLot = 0.0;
   if(!OrderCalcProfit(type, _Symbol, 1.0, entry, stop, profitOneLot))
      return 0.0;

   double lossOneLot = MathAbs(profitOneLot);
   if(lossOneLot <= 0.0)
      return 0.0;

   return NormalizeVolume(riskMoney / lossOneLot);
}

bool OversizedCandle(const MqlRates &candle, const double atr)
{
   if(InpMaxCandleATR <= 0.0 || atr <= 0.0)
      return false;

   return ((candle.high - candle.low) > atr * InpMaxCandleATR);
}

bool BullishPinBar(const MqlRates &c)
{
   double body = MathAbs(c.close-c.open);
   double range = c.high-c.low;
   if(range <= 0.0)
      return false;

   double lower = MathMin(c.open,c.close)-c.low;
   double upper = c.high-MathMax(c.open,c.close);

   return (c.close > c.open &&
           lower >= MathMax(body*_Point, body*InpPinWickBodyRatio) &&
           lower > upper);
}

bool BearishPinBar(const MqlRates &c)
{
   double body = MathAbs(c.close-c.open);
   double range = c.high-c.low;
   if(range <= 0.0)
      return false;

   double upper = c.high-MathMax(c.open,c.close);
   double lower = MathMin(c.open,c.close)-c.low;

   return (c.close < c.open &&
           upper >= MathMax(body*_Point, body*InpPinWickBodyRatio) &&
           upper > lower);
}

bool BullishEngulfing(const MqlRates &c, const MqlRates &p)
{
   return (c.close > c.open &&
           p.close < p.open &&
           c.open <= p.close &&
           c.close >= p.open);
}

bool BearishEngulfing(const MqlRates &c, const MqlRates &p)
{
   return (c.close < c.open &&
           p.close > p.open &&
           c.open >= p.close &&
           c.close <= p.open);
}

bool BullishStrongRejection(const MqlRates &c)
{
   double body = MathAbs(c.close-c.open);
   double lower = MathMin(c.open,c.close)-c.low;
   return (c.close > c.open && lower >= MathMax(body*_Point, body*InpStrongWickRatio));
}

bool BearishStrongRejection(const MqlRates &c)
{
   double body = MathAbs(c.close-c.open);
   double upper = c.high-MathMax(c.open,c.close);
   return (c.close < c.open && upper >= MathMax(body*_Point, body*InpStrongWickRatio));
}

bool BullishMarubozu(const MqlRates &c)
{
   double range = c.high-c.low;
   if(range <= 0.0 || c.close <= c.open)
      return false;

   double upper = c.high-c.close;
   double lower = c.open-c.low;

   return (upper <= range*InpMarubozuWickRatio &&
           lower <= range*InpMarubozuWickRatio);
}

bool BearishMarubozu(const MqlRates &c)
{
   double range = c.high-c.low;
   if(range <= 0.0 || c.close >= c.open)
      return false;

   double upper = c.high-c.open;
   double lower = c.close-c.low;

   return (upper <= range*InpMarubozuWickRatio &&
           lower <= range*InpMarubozuWickRatio);
}

bool ValidBullishRejection(const MqlRates &c, const MqlRates &p, const double atr)
{
   if(OversizedCandle(c, atr))
      return false;

   if(InpUsePinBar && BullishPinBar(c))
      return true;
   if(InpUseEngulfing && BullishEngulfing(c,p))
      return true;
   if(InpUseStrongRejection && BullishStrongRejection(c))
      return true;
   if(InpUseMarubozu && BullishMarubozu(c))
      return true;

   return false;
}

bool ValidBearishRejection(const MqlRates &c, const MqlRates &p, const double atr)
{
   if(OversizedCandle(c, atr))
      return false;

   if(InpUsePinBar && BearishPinBar(c))
      return true;
   if(InpUseEngulfing && BearishEngulfing(c,p))
      return true;
   if(InpUseStrongRejection && BearishStrongRejection(c))
      return true;
   if(InpUseMarubozu && BearishMarubozu(c))
      return true;

   return false;
}

bool PriceTouchedLevel(const MqlRates &candle, const double level, const double tolerance)
{
   return (candle.low <= level+tolerance && candle.high >= level-tolerance);
}

void DetectBOS()
{
   if(g_setup.direction != SETUP_NONE)
      return;

   MqlRates r[];
   if(!GetRates(r, 120))
      return;

   // Closed candle 1 is the BOS candle. Compare it with the latest
   // confirmed swing that existed before that candle.
   double swingHigh=0.0, swingLow=0.0;
   int highShift=-1, lowShift=-1;

   if(InpAllowBuy && H1BullishStructure() && IsHTFBullish())
   {
      if(GetMostRecentSwingHigh(swingHigh, highShift))
      {
         if(r[1].close > swingHigh &&
            highShift > 1 &&
            r[1].time > r[highShift].time)
         {
            if(InpMinSwingDistancePts <= 0 ||
               (r[1].close-swingHigh) >= InpMinSwingDistancePts*_Point)
            {
               g_setup.direction = SETUP_BUY;
               g_setup.level = swingHigh;
               g_setup.bosTime = r[1].time;
               g_setup.bosShift = 1;
               g_setup.retested = false;
               g_setup.traded = false;
               return;
            }
         }
      }
   }

   if(InpAllowSell && H1BearishStructure() && IsHTFBearish())
   {
      if(GetMostRecentSwingLow(swingLow, lowShift))
      {
         if(r[1].close < swingLow &&
            lowShift > 1 &&
            r[1].time > r[lowShift].time)
         {
            if(InpMinSwingDistancePts <= 0 ||
               (swingLow-r[1].close) >= InpMinSwingDistancePts*_Point)
            {
               g_setup.direction = SETUP_SELL;
               g_setup.level = swingLow;
               g_setup.bosTime = r[1].time;
               g_setup.bosShift = 1;
               g_setup.retested = false;
               g_setup.traded = false;
            }
         }
      }
   }
}

bool SetupExpired()
{
   if(g_setup.direction == SETUP_NONE)
      return false;

   int shift = iBarShift(_Symbol, InpSignalTimeframe, g_setup.bosTime, true);
   if(shift < 0)
      return true;

   return (shift > InpMaxBarsAfterBOS);
}

bool SetupRetested(const MqlRates &r[], const double atr)
{
   if(g_setup.direction == SETUP_NONE)
      return false;

   int barsSinceBOS = iBarShift(_Symbol, InpSignalTimeframe, g_setup.bosTime, true);
   if(barsSinceBOS < 0)
      return false;

   // We inspect the latest closed candle and require a genuine return
   // to the broken level after the BOS.
   double tolerance = atr * InpRetestToleranceATR;

   if(barsSinceBOS >= InpMinRetestBars)
   {
      if(PriceTouchedLevel(r[1], g_setup.level, tolerance))
         return true;
   }

   return false;
}

void ProcessSetup()
{
   if(g_setup.direction == SETUP_NONE)
      return;

   if(SetupExpired())
   {
      ResetSetup();
      return;
   }

   if(HasOpenPosition())
      return;

   if(!SpreadOK())
      return;

   MqlRates r[];
   if(!GetRates(r, 5))
      return;

   double atr = GetATR(1);
   if(atr <= 0.0)
      return;

   if(!g_setup.retested)
   {
      if(SetupRetested(r, atr))
         g_setup.retested = true;

      return;
   }

   // The rejection candle is the last closed H1 candle.
   if(g_setup.direction == SETUP_BUY)
   {
      if(!ValidBullishRejection(r[1], r[2], atr))
         return;

      // The rejection must interact with the broken resistance/support zone.
      double tolerance = atr * InpRetestToleranceATR;
      if(!PriceTouchedLevel(r[1], g_setup.level, tolerance))
         return;

      ExecuteBuy(r[1], atr);
   }
   else if(g_setup.direction == SETUP_SELL)
   {
      if(!ValidBearishRejection(r[1], r[2], atr))
         return;

      double tolerance = atr * InpRetestToleranceATR;
      if(!PriceTouchedLevel(r[1], g_setup.level, tolerance))
         return;

      ExecuteSell(r[1], atr);
   }
}

void ExecuteBuy(const MqlRates &rejection, const double atr)
{
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return;

   double entry = tick.ask;
   double sl = rejection.low - atr*InpSLBufferATR;

   double minStop = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   if(minStop > 0.0 && (entry-sl) < minStop)
      sl = entry-minStop;

   double risk = entry-sl;
   if(risk <= 0.0)
      return;

   if(InpMaxSLDistanceATR > 0.0 && risk > atr*InpMaxSLDistanceATR)
      return;

   double tp = entry + risk*InpRiskReward;

   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   sl = NormalizeDouble(sl,digits);
   tp = NormalizeDouble(tp,digits);

   double volume = CalculateRiskLot(ORDER_TYPE_BUY, entry, sl);
   if(volume <= 0.0)
      return;

   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   if(trade.Buy(volume,_Symbol,0.0,sl,tp,"BOS Retest BUY"))
   {
      g_setup.traded = true;
      ResetSetup();
   }
}

void ExecuteSell(const MqlRates &rejection, const double atr)
{
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
      return;

   double entry = tick.bid;
   double sl = rejection.high + atr*InpSLBufferATR;

   double minStop = (double)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   if(minStop > 0.0 && (sl-entry) < minStop)
      sl = entry+minStop;

   double risk = sl-entry;
   if(risk <= 0.0)
      return;

   if(InpMaxSLDistanceATR > 0.0 && risk > atr*InpMaxSLDistanceATR)
      return;

   double tp = entry - risk*InpRiskReward;

   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   sl = NormalizeDouble(sl,digits);
   tp = NormalizeDouble(tp,digits);

   double volume = CalculateRiskLot(ORDER_TYPE_SELL, entry, sl);
   if(volume <= 0.0)
      return;

   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   if(trade.Sell(volume,_Symbol,0.0,sl,tp,"BOS Retest SELL"))
   {
      g_setup.traded = true;
      ResetSetup();
   }
}

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
{
   if(InpSwingStrength < 1 ||
      InpHTFSwingStrength < 1 ||
      InpATRPeriod < 1 ||
      InpRiskReward <= 0.0 ||
      InpSLBufferATR < 0.0 ||
      InpRetestToleranceATR < 0.0 ||
      InpMaxBarsAfterBOS < 1)
   {
      return INIT_PARAMETERS_INCORRECT;
   }

   g_atrHandle = iATR(_Symbol, InpSignalTimeframe, InpATRPeriod);
   if(g_atrHandle == INVALID_HANDLE)
      return INIT_FAILED;

   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   ResetSetup();
   g_lastBarTime = iTime(_Symbol, InpSignalTimeframe, 0);

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(g_atrHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_atrHandle);
      g_atrHandle = INVALID_HANDLE;
   }
}

//+------------------------------------------------------------------+
//| Expert tick                                                      |
//+------------------------------------------------------------------+
void OnTick()
{
   //Show Equity and Balance
   Comment ( StringFormat ( "Equity is %.2f and Balance is %.2f", AccountInfoDouble (ACCOUNT_EQUITY), AccountInfoDouble(ACCOUNT_BALANCE)));  
   if(!IsNewBar())
      return;

   // A setup can only be acted upon at the open of a new signal candle.
   // Therefore the previous H1 candle is always fully closed.
   ProcessSetup();

   // Detect a fresh BOS only after the current setup has been processed.
   if(g_setup.direction == SETUP_NONE)
      DetectBOS();
}
//+------------------------------------------------------------------+
