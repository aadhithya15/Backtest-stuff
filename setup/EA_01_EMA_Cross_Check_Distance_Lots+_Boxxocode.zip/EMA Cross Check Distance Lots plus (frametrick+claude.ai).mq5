//+------------------------------------------------------------------+
//|                            EMA_Cross_Check_Distance_Lots_Plus.mq5 |
//|                  EMA Cross Check Distance Lots+ (Boxxocode)       |
//|                                                                    |
//|  Strategy:                                                        |
//|   - BUY  : EMA_fast crosses ABOVE EMA_slow (confirmed 2-bar cross |
//|            at shift Signal_ID) AND EMA distance at shift 1 >=     |
//|            Distance_points, with fast ABOVE slow.                 |
//|   - SELL : EMA_fast crosses BELOW EMA_slow (confirmed 2-bar cross |
//|            at shift Signal_ID) AND EMA distance at shift 1 >=     |
//|            Distance_points, with fast BELOW slow.                 |
//|   - Only one position per direction is allowed (gated by Magic).  |
//|   - Once-per-bar execution.                                       |
//|   - Progressive (martingale-style) lot sizing: lot size increases |
//|     by Lots_plus per consecutive loss (starting after 1 loss),    |
//|     and resets to Lot_start after any winning trade.              |
//+------------------------------------------------------------------+
#property copyright "Boxxocode"
#property link      ""
#property version   "1.00"
#property strict

#include <Trade\Trade.mqh>

//====================================================================
// INPUT PARAMETERS
//====================================================================
input int    Magic_Number   = 123456;                                // Magic Number
input string EA_Name        = "EMA Cross Check Distance Lots+ (Boxxocode)"; // EA Comment / Name
input double Lot_start      = 0.1;                                   // Base Lot Size
input double Lots_plus      = 0.1;                                   // Lot increment per consecutive loss
input int    SL_points      = 200;                                   // Stop Loss (points)
input int    TP_points      = 600;                                   // Take Profit (points)
input int    Distance_points= 40;                                    // Min EMA distance (points)
input int    Signal_ID      = 2;                                     // Shift used for crossover signal bar
input int    EMA_fast       = 12;                                    // Fast EMA period
input int    EMA_slow       = 25;                                    // Slow EMA period
input int    Slippage_points= 30;                                    // Slippage tolerance (points)

//====================================================================
// GLOBALS
//====================================================================
CTrade      trade;

int         g_handleEmaFast = INVALID_HANDLE;   // fast EMA handle (used at Signal_ID and at shift 1)
int         g_handleEmaSlow = INVALID_HANDLE;   // slow EMA handle (used at Signal_ID and at shift 1)

datetime    g_lastBarTimeBuy  = 0;   // once-per-bar guard for buy branch
datetime    g_lastBarTimeSell = 0;   // once-per-bar guard for sell branch

//+------------------------------------------------------------------+
//| Expert initialization function                                    |
//+------------------------------------------------------------------+
int OnInit()
  {
   trade.SetExpertMagicNumber(Magic_Number);
   trade.SetDeviationInPoints(Slippage_points);
   trade.SetTypeFillingBySymbol(_Symbol);

   // --- Create indicator handles once ---
   g_handleEmaFast = iMA(_Symbol, PERIOD_CURRENT, EMA_fast, 0, MODE_EMA, PRICE_CLOSE);
   g_handleEmaSlow = iMA(_Symbol, PERIOD_CURRENT, EMA_slow, 0, MODE_EMA, PRICE_CLOSE);

   if(g_handleEmaFast == INVALID_HANDLE || g_handleEmaSlow == INVALID_HANDLE)
     {
      Print("EA Init Error: Failed to create EMA indicator handle(s). Error code: ", GetLastError());
      return(INIT_FAILED);
     }

   // Basic input validation
   if(EMA_fast <= 0 || EMA_slow <= 0)
     {
      Print("EA Init Error: EMA periods must be > 0");
      return(INIT_FAILED);
     }
   if(Lot_start <= 0)
     {
      Print("EA Init Error: Lot_start must be > 0");
      return(INIT_FAILED);
     }

   Print(EA_Name, " initialized successfully. Magic=", Magic_Number);
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   if(g_handleEmaFast != INVALID_HANDLE)
      IndicatorRelease(g_handleEmaFast);
   if(g_handleEmaSlow != INVALID_HANDLE)
      IndicatorRelease(g_handleEmaSlow);
  }

//+------------------------------------------------------------------+
//| Helper: get a single EMA value at given shift from a handle       |
//| Returns true on success, fills 'value'                            |
//+------------------------------------------------------------------+
bool GetEmaValue(const int handle, const int shift, double &value)
  {
   double buf[];
   ArraySetAsSeries(buf, true);
   int copied = CopyBuffer(handle, 0, shift, 1, buf);
   if(copied <= 0)
     {
      Print("GetEmaValue: CopyBuffer failed for shift ", shift, ". Error: ", GetLastError());
      return(false);
     }
   value = buf[0];
   return(true);
  }

//+------------------------------------------------------------------+
//| Helper: does an open position with our Magic Number & given type  |
//| exist on this symbol?                                             |
//+------------------------------------------------------------------+
bool HasOpenPosition(const ENUM_POSITION_TYPE posType)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((long)PositionGetInteger(POSITION_MAGIC) != Magic_Number)
         continue;
      if((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) == posType)
         return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Helper: any open position (buy or sell) for our Magic Number?     |
//+------------------------------------------------------------------+
bool HasAnyOpenPosition()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)
         continue;
      if(!PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((long)PositionGetInteger(POSITION_MAGIC) == Magic_Number)
         return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| Count consecutive losses from closed deal history (most recent    |
//| trades first) for this Symbol & Magic Number.                     |
//| Stops counting at the first winning trade (Profit > 0) found.     |
//+------------------------------------------------------------------+
int CountConsecutiveLosses()
  {
   if(!HistorySelect(0, TimeCurrent()))
     {
      Print("CountConsecutiveLosses: HistorySelect failed. Error: ", GetLastError());
      return(0);
     }

   int totalDeals = HistoryDealsTotal();
   int consecutiveLosses = 0;

   // Collect qualifying closing deals (DEAL_ENTRY_OUT) for our symbol/magic,
   // then walk them from most recent to oldest.
   ulong dealTickets[];
   ArrayResize(dealTickets, 0);

   for(int i = 0; i < totalDeals; i++)
     {
      ulong dealTicket = HistoryDealGetTicket(i);
      if(dealTicket == 0)
         continue;

      if(HistoryDealGetString(dealTicket, DEAL_SYMBOL) != _Symbol)
         continue;
      if((long)HistoryDealGetInteger(dealTicket, DEAL_MAGIC) != Magic_Number)
         continue;

      ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
      if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY)
         continue; // only closing deals represent a completed trade result

      int sz = ArraySize(dealTickets);
      ArrayResize(dealTickets, sz + 1);
      dealTickets[sz] = dealTicket;
     }

   int n = ArraySize(dealTickets);
   if(n == 0)
      return(0);

   // Deals are naturally in chronological (oldest -> newest) order from
   // HistoryDealsTotal()/HistoryDealGetTicket(), so walk backwards (newest first).
   for(int i = n - 1; i >= 0; i--)
     {
      ulong dealTicket = dealTickets[i];
      double profit = HistoryDealGetDouble(dealTicket, DEAL_PROFIT)
                     + HistoryDealGetDouble(dealTicket, DEAL_SWAP)
                     + HistoryDealGetDouble(dealTicket, DEAL_COMMISSION);

      if(profit > 0.0)
        {
         // Winning trade found -> stop counting, consecutive loss streak ends here
         break;
        }
      else
        {
         consecutiveLosses++;
        }
     }

   return(consecutiveLosses);
  }

//+------------------------------------------------------------------+
//| Compute lot size for the next trade based on progressive betting  |
//| (martingale-style) rules, normalized to broker constraints.       |
//+------------------------------------------------------------------+
double CalculateLotSize()
  {
   int consecutiveLosses = CountConsecutiveLosses();

   double lot = Lot_start;
   if(consecutiveLosses >= 1)
      lot = Lot_start + (Lots_plus * consecutiveLosses);

   // --- Normalize to broker constraints ---
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(lotStep > 0)
      lot = MathRound(lot / lotStep) * lotStep;

   if(lot < minLot)
      lot = minLot;
   if(lot > maxLot)
      lot = maxLot;

   int lotDigits = 2;
   if(lotStep == 0.01) lotDigits = 2;
   else if(lotStep == 0.1) lotDigits = 1;
   else if(lotStep >= 1.0) lotDigits = 0;

   lot = NormalizeDouble(lot, lotDigits);

   return(lot);
  }

//+------------------------------------------------------------------+
//| Check whether a new bar has formed for the given "last bar time"  |
//| tracker (Once Per Bar filter). Returns true only on the first     |
//| tick of a new bar, and updates the tracker.                       |
//+------------------------------------------------------------------+
bool IsNewBar(datetime &lastBarTimeTracker)
  {
   datetime currentBarTime = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(currentBarTime == 0)
      return(false); // data not ready

   if(currentBarTime != lastBarTimeTracker)
     {
      lastBarTimeTracker = currentBarTime;
      return(true);
     }
   return(false);
  }

//+------------------------------------------------------------------+
//| CheckBuySignal()                                                  |
//| Evaluates all Branch 1 (Long) conditions independently of Sell.   |
//+------------------------------------------------------------------+
bool CheckBuySignal()
  {
   // --- Filter 1: No active position for this Magic Number ---
   if(HasAnyOpenPosition())
      return(false);

   // --- Filter 4: Once per bar (separate tracker for buy branch) ---
   if(!IsNewBar(g_lastBarTimeBuy))
      return(false);

   // --- Filter 2: Bullish crossover confirmed over 2 bars at Signal_ID ---
   double fastSignal, fastSignalPrior;
   double slowSignal, slowSignalPrior;

   if(!GetEmaValue(g_handleEmaFast, Signal_ID,     fastSignal))      return(false);
   if(!GetEmaValue(g_handleEmaFast, Signal_ID + 1, fastSignalPrior)) return(false);
   if(!GetEmaValue(g_handleEmaSlow, Signal_ID,     slowSignal))      return(false);
   if(!GetEmaValue(g_handleEmaSlow, Signal_ID + 1, slowSignalPrior)) return(false);

   bool crossedAbove = (fastSignal > slowSignal) && (fastSignalPrior <= slowSignalPrior);
   if(!crossedAbove)
      return(false);

   // --- Filter 3: Distance check at shift 1, fast must be ABOVE slow ---
   double fastShift1, slowShift1;
   if(!GetEmaValue(g_handleEmaFast, 1, fastShift1)) return(false);
   if(!GetEmaValue(g_handleEmaSlow, 1, slowShift1)) return(false);

   double distancePoints = (fastShift1 - slowShift1) / _Point;
   if(!(fastShift1 > slowShift1 && distancePoints >= Distance_points))
      return(false);

   return(true); // all Buy conditions satisfied
  }

//+------------------------------------------------------------------+
//| CheckSellSignal()                                                  |
//| Evaluates all Branch 2 (Short) conditions independently of Buy.    |
//+------------------------------------------------------------------+
bool CheckSellSignal()
  {
   // --- Filter 1: No active position for this Magic Number ---
   if(HasAnyOpenPosition())
      return(false);

   // --- Filter 4: Once per bar (separate tracker for sell branch) ---
   if(!IsNewBar(g_lastBarTimeSell))
      return(false);

   // --- Filter 2: Bearish crossunder confirmed over 2 bars at Signal_ID ---
   double fastSignal, fastSignalPrior;
   double slowSignal, slowSignalPrior;

   if(!GetEmaValue(g_handleEmaFast, Signal_ID,     fastSignal))      return(false);
   if(!GetEmaValue(g_handleEmaFast, Signal_ID + 1, fastSignalPrior)) return(false);
   if(!GetEmaValue(g_handleEmaSlow, Signal_ID,     slowSignal))      return(false);
   if(!GetEmaValue(g_handleEmaSlow, Signal_ID + 1, slowSignalPrior)) return(false);

   bool crossedBelow = (fastSignal < slowSignal) && (fastSignalPrior >= slowSignalPrior);
   if(!crossedBelow)
      return(false);

   // --- Filter 3: Distance check at shift 1, fast must be BELOW slow ---
   double fastShift1, slowShift1;
   if(!GetEmaValue(g_handleEmaFast, 1, fastShift1)) return(false);
   if(!GetEmaValue(g_handleEmaSlow, 1, slowShift1)) return(false);

   double distancePoints = (slowShift1 - fastShift1) / _Point;
   if(!(fastShift1 < slowShift1 && distancePoints >= Distance_points))
      return(false);

   return(true); // all Sell conditions satisfied
  }

//+------------------------------------------------------------------+
//| ExecuteBuy() - places a Market Buy order with SL/TP                |
//+------------------------------------------------------------------+
void ExecuteBuy()
  {
   double lot = CalculateLotSize();

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   int    digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   double sl = (SL_points > 0) ? NormalizeDouble(ask - SL_points * _Point, digits) : 0.0;
   double tp = (TP_points > 0) ? NormalizeDouble(ask + TP_points * _Point, digits) : 0.0;

   trade.SetDeviationInPoints(Slippage_points);

   if(!trade.Buy(lot, _Symbol, ask, sl, tp, EA_Name))
     {
      Print("ExecuteBuy failed. RetCode=", trade.ResultRetcode(),
            " Desc=", trade.ResultRetcodeDescription(),
            " LastError=", GetLastError());
     }
   else
     {
      Print("BUY order placed. Lot=", lot, " SL=", sl, " TP=", tp);
     }
  }

//+------------------------------------------------------------------+
//| ExecuteSell() - places a Market Sell order with SL/TP              |
//+------------------------------------------------------------------+
void ExecuteSell()
  {
   double lot = CalculateLotSize();

   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   int    digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);

   double sl = (SL_points > 0) ? NormalizeDouble(bid + SL_points * _Point, digits) : 0.0;
   double tp = (TP_points > 0) ? NormalizeDouble(bid - TP_points * _Point, digits) : 0.0;

   trade.SetDeviationInPoints(Slippage_points);

   if(!trade.Sell(lot, _Symbol, bid, sl, tp, EA_Name))
     {
      Print("ExecuteSell failed. RetCode=", trade.ResultRetcode(),
            " Desc=", trade.ResultRetcodeDescription(),
            " LastError=", GetLastError());
     }
   else
     {
      Print("SELL order placed. Lot=", lot, " SL=", sl, " TP=", tp);
     }
  }

//+------------------------------------------------------------------+
//| Expert tick function                                              |
//+------------------------------------------------------------------+
void OnTick()
  {
   // Ensure enough bars are available for indicator calculation
   if(Bars(_Symbol, PERIOD_CURRENT) < (EMA_slow + Signal_ID + 5))
      return;

   // --- Branch 1: Long / Buy ---
   if(CheckBuySignal())
      ExecuteBuy();

   // --- Branch 2: Short / Sell ---
   if(CheckSellSignal())
      ExecuteSell();
  }
//+------------------------------------------------------------------+